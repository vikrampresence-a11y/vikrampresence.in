import React from 'react';
import { Helmet } from 'react-helmet';
import ScrollReveal from '@/components/ScrollReveal.jsx';
import PodcastCard from '@/components/PodcastCard.jsx';

const mockPodcasts = Array.from({ length: 6 }).map((_, i) => ({
  id: i + 1,
  title: `The Clarity Protocol: Vol ${i + 1}`,
  description: 'A deep dive into dismantling mental barriers, auditing your focus, and finding absolute clarity in a distracted world. No fluff, just frameworks.',
  episodes: Math.floor(Math.random() * 10) + 3,
  price: '₹199',
}));

const PodcastsPage = () => {
  return (
    <>
      <Helmet>
        <title>Podcasts | Vikram Presence</title>
        <meta name="description" content="Listen to Vikram Presence podcasts for mental clarity and discipline." />
      </Helmet>

      <div className="bg-black min-h-screen text-white pt-40 pb-32">
        <div className="container mx-auto px-6 max-w-7xl">
          <ScrollReveal>
            <div className="mb-20">
              <h1 className="text-5xl md:text-7xl font-bold mb-6 tracking-tighter">Audio Frameworks</h1>
              <p className="text-xl md:text-2xl text-gray-400 max-w-3xl font-light leading-relaxed">
                Designed for your commute, workout, or quiet moments of reflection. Rebuild your mental architecture through focused listening.
              </p>
            </div>
          </ScrollReveal>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
            {mockPodcasts.map((podcast, index) => (
              <ScrollReveal key={podcast.id} delay={index * 100}>
                <PodcastCard {...podcast} />
              </ScrollReveal>
            ))}
          </div>
        </div>
      </div>
    </>
  );
};

export default PodcastsPage;