
import React, { useState, useEffect } from 'react';
import { Helmet } from 'react-helmet';
import { Link } from 'react-router-dom';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import pb from '@/lib/pocketbaseClient';

const HomePage = () => {
  const [featuredProducts, setFeaturedProducts] = useState([]);

  useEffect(() => {
    const fetchFeatured = async () => {
      try {
        const records = await pb.collection('products').getList(1, 6, {
          sort: '-created',
          $autoCancel: false
        });
        setFeaturedProducts(records.items);
      } catch (error) {
        console.error("Error fetching featured products:", error);
      }
    };
    fetchFeatured();
  }, []);

  const getImageUrl = record => {
    if (record.image) {
      return pb.files.getUrl(record, record.image);
    }
    return record.type === 'ebook' ? 'https://images.unsplash.com/photo-1544453271-bad31b39b097?auto=format&fit=crop&w=600&q=80' : 'https://images.unsplash.com/photo-1606761568499-6d2451b23c66?auto=format&fit=crop&w=600&q=80';
  };

  return (
    <>
      <Helmet>
        <title>Vikram Presence - Premium Ebooks & Courses for Self-Improvement</title>
        <meta name="description" content="Learn clarity, discipline, and confidence with premium ebooks and courses. Start your transformation today." />
        <meta name="keywords" content="ebooks, online courses, self-improvement, clarity, discipline, confidence, personal growth" />
      </Helmet>

      <div className="bg-black min-h-screen text-white selection:bg-[#FFD700] selection:text-black font-sans">
        
        {/* 1. Hero Section */}
        <section className="relative min-h-screen flex items-center justify-center overflow-hidden pt-20">
          <div className="absolute inset-0 z-0">
            <div className="absolute inset-0 bg-gradient-to-b from-black via-black/90 to-black"></div>
          </div>

          <div className="relative z-10 container mx-auto px-6 text-center flex flex-col items-center">
            
            {/* Rotating Fire Animation */}
            <motion.div animate={{ rotate: 360 }} transition={{ duration: 20, repeat: Infinity, ease: "linear" }} className="relative w-32 h-32 mb-12 flex items-center justify-center">
              <div className="absolute inset-0 rounded-full border border-[#FFD700]/30 shadow-[0_0_50px_rgba(255,215,0,0.2)]"></div>
              <div className="absolute inset-2 rounded-full border border-orange-500/20 shadow-[0_0_30px_rgba(255,165,0,0.3)]"></div>
              <motion.div animate={{ scale: [1, 1.1, 1] }} transition={{ duration: 4, repeat: Infinity, ease: "easeInOut" }} className="w-16 h-16 rounded-full bg-gradient-to-tr from-[#FFD700] to-orange-600 blur-md opacity-80"></motion.div>
            </motion.div>

            <motion.h1 initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8 }} className="text-5xl md:text-7xl lg:text-8xl font-bold text-white mb-6 tracking-tighter drop-shadow-[0_0_15px_rgba(255,255,255,0.3)]">
              Vikram <span className="text-[#FFD700] drop-shadow-[0_0_20px_rgba(255,215,0,0.5)]">Presence</span>
            </motion.h1>
            
            <motion.p initial={{ opacity: 0 }} animate={{ opacity: 1 }} transition={{ duration: 0.8, delay: 0.2 }} className="text-xl md:text-2xl text-white mb-16 font-light max-w-2xl mx-auto tracking-wide">
              Get clear. Build habits. Be confident.
            </motion.p>

            <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.8, delay: 0.4 }} className="flex flex-col sm:flex-row items-center gap-6 mb-12">
              <Link to="/ebooks" className="group relative px-12 py-4 bg-transparent border border-[#FFD700] rounded-full overflow-hidden transition-all shadow-[0_0_20px_rgba(255,215,0,0.4)] hover:shadow-[0_0_40px_rgba(255,215,0,0.8)]">
                <div className="absolute inset-0 bg-[#FFD700]/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out"></div>
                <span className="relative text-[#FFD700] font-bold uppercase tracking-widest text-sm">EBOOKS</span>
              </Link>
              
              <Link to="/courses" className="group relative px-12 py-4 bg-transparent border border-[#FFD700] rounded-full overflow-hidden transition-all shadow-[0_0_20px_rgba(255,215,0,0.4)] hover:shadow-[0_0_40px_rgba(255,215,0,0.8)]">
                <div className="absolute inset-0 bg-[#FFD700]/20 translate-y-full group-hover:translate-y-0 transition-transform duration-300 ease-out"></div>
                <span className="relative text-[#FFD700] font-bold uppercase tracking-widest text-sm">COURSES</span>
              </Link>
            </motion.div>
          </div>
        </section>

        {/* 2. Featured Products */}
        <section className="py-32 bg-black">
          <div className="container mx-auto px-6">
            <motion.div initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="text-center mb-20">
              <h2 className="text-3xl md:text-5xl font-bold tracking-tighter mb-4 text-white drop-shadow-[0_0_10px_rgba(255,255,255,0.2)]">Featured Products</h2>
            </motion.div>

            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-10 max-w-7xl mx-auto">
              {featuredProducts.map((product, index) => (
                <motion.div key={product.id} initial={{ opacity: 0, y: 30 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ duration: 0.5, delay: index * 0.1 }}>
                  <Link to={`/product/${product.id}`} className="block group h-full">
                    <div className="bg-[#0a0a0a] border border-[#FFD700]/20 rounded-2xl overflow-hidden transition-all duration-500 hover:border-[#FFD700] shadow-[0_0_15px_rgba(255,215,0,0.05)] hover:shadow-[0_0_30px_rgba(255,215,0,0.2)] h-full flex flex-col">
                      <div className="aspect-[4/3] overflow-hidden relative">
                        <div className="absolute inset-0 bg-black/40 group-hover:bg-transparent transition-colors duration-500 z-10"></div>
                        <img src={getImageUrl(product)} alt={product.title} className="w-full h-full object-cover grayscale group-hover:grayscale-0 transition-all duration-700 group-hover:scale-105" />
                        <div className="absolute top-4 left-4 z-20">
                          <span className="px-3 py-1 bg-black/80 backdrop-blur-md border border-[#FFD700]/50 rounded-full text-[10px] font-bold uppercase tracking-widest text-[#FFD700] shadow-[0_0_10px_rgba(0,0,0,0.5)]">
                            {product.type}
                          </span>
                        </div>
                      </div>
                      <div className="p-8 flex flex-col flex-grow">
                        <h3 className="text-xl font-bold text-white mb-3 group-hover:text-[#FFD700] transition-colors drop-shadow-sm">{product.title}</h3>
                        <p className="text-white text-sm font-light line-clamp-2 mb-6 flex-grow">{product.description}</p>
                        <div className="flex justify-between items-center mt-auto pt-4 border-t border-white/10">
                          <span className="text-xl font-bold text-white">₹{product.price}</span>
                          <span className="text-xs font-bold uppercase tracking-widest text-[#FFD700] opacity-0 group-hover:opacity-100 transition-opacity flex items-center">
                            View <ArrowRight size={14} className="ml-1" />
                          </span>
                        </div>
                      </div>
                    </div>
                  </Link>
                </motion.div>
              ))}
            </div>
          </div>
        </section>

        {/* 3. CTA / About Section */}
        <section className="py-32 bg-[#050505] relative overflow-hidden border-t border-white/5">
          <div className="absolute inset-0 bg-gradient-to-t from-[#FFD700]/10 to-transparent"></div>
          <div className="container mx-auto px-6 relative z-10 text-center">
            <motion.h2 initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} className="text-4xl md:text-6xl font-bold text-white mb-8 tracking-tighter drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">
              Start Your Journey
            </motion.h2>
            <motion.p initial={{ opacity: 0 }} whileInView={{ opacity: 1 }} viewport={{ once: true }} transition={{ delay: 0.2 }} className="text-xl text-white font-light mb-12 max-w-2xl mx-auto">
              Stop waiting. Start building good habits today.
            </motion.p>
            <motion.div initial={{ opacity: 0, y: 20 }} whileInView={{ opacity: 1, y: 0 }} viewport={{ once: true }} transition={{ delay: 0.4 }}>
              <Link to="/shop" className="inline-block px-12 py-5 bg-[#FFD700] text-black font-bold uppercase tracking-widest text-sm rounded-full hover:bg-yellow-400 hover:scale-105 transition-all shadow-[0_0_30px_rgba(255,215,0,0.5)] hover:shadow-[0_0_50px_rgba(255,215,0,0.8)]">
                Explore All Products
              </Link>
            </motion.div>
          </div>
        </section>

      </div>
    </>
  );
};

export default HomePage;
