import React from 'react';
import { Helmet } from 'react-helmet';
import { useParams, Link } from 'react-router-dom';
import { Play, SkipBack, SkipForward, Download, ArrowLeft } from 'lucide-react';
import { useToast } from '@/components/ui/use-toast';
import ScrollReveal from '@/components/ScrollReveal.jsx';
import RazorpayCheckout from '@/components/RazorpayCheckout.jsx';

const PodcastDetailPage = () => {
  const { id } = useParams();
  const { toast } = useToast();

  const handleAction = (action) => {
    toast({
      title: `🚧 ${action} not implemented`,
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  const episodes = [
    { title: '01. The Illusion of Being Stuck', time: '45:20' },
    { title: '02. Auditing Your Mental Diet', time: '38:15' },
    { title: '03. The Discipline of Subtraction', time: '52:10' },
    { title: '04. Building the Baseline', time: '41:05' },
  ];

  return (
    <>
      <Helmet>
        <title>{`Podcast Vol ${id} | Vikram Presence`}</title>
      </Helmet>

      <div className="bg-black min-h-screen text-white pt-40 pb-32">
        <div className="container mx-auto px-6 max-w-4xl">
          <ScrollReveal>
            <Link to="/podcasts" className="inline-flex items-center text-gray-400 hover:text-white text-sm uppercase tracking-widest mb-12 transition-colors group">
              <ArrowLeft size={16} className="mr-2 group-hover:-translate-x-1 transition-transform" /> Back to Audio
            </Link>

            <div className="mb-20">
              <div className="flex items-center space-x-4 mb-6">
                <span className="px-3 py-1 bg-white/10 rounded-full text-xs uppercase tracking-widest font-semibold border border-white/10">
                  Audio Series
                </span>
                <span className="text-gray-500 text-sm font-mono">Vol {id}</span>
              </div>
              
              <h1 className="text-5xl md:text-7xl font-bold mb-8 tracking-tighter leading-tight">The Clarity Protocol</h1>
              
              <p className="text-xl text-gray-300 leading-relaxed mb-12 font-light">
                In this comprehensive series, we break down the exact mechanisms that keep you mentally paralyzed and provide the tools to break free. No fluff, just actionable insights designed to rewire your approach to daily friction.
              </p>

              <div className="flex items-center space-x-8 mb-16 pb-12 border-b border-white/10">
                <div className="text-4xl font-bold">₹199</div>
                <RazorpayCheckout 
                  amount={199} 
                  productName={`The Clarity Protocol Vol ${id}`} 
                  buttonText="Purchase Access"
                />
              </div>

              {/* Cinematic Audio Player */}
              <div className="bg-black border border-white/20 rounded-2xl p-10 mb-20 shadow-2xl relative overflow-hidden">
                <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent pointer-events-none"></div>
                
                <div className="relative z-10">
                  <div className="flex flex-col md:flex-row items-center justify-between mb-12 gap-8">
                    <div className="flex items-center space-x-8">
                      <button onClick={() => handleAction('Skip Back')} className="text-gray-400 hover:text-white transition-colors hover:scale-110 transform"><SkipBack size={28} /></button>
                      <button onClick={() => handleAction('Play')} className="w-20 h-20 bg-white text-black rounded-full flex items-center justify-center hover:scale-105 transition-transform shadow-[0_0_30px_rgba(255,255,255,0.3)]">
                        <Play size={36} className="ml-2" />
                      </button>
                      <button onClick={() => handleAction('Skip Forward')} className="text-gray-400 hover:text-white transition-colors hover:scale-110 transform"><SkipForward size={28} /></button>
                    </div>
                    
                    <button onClick={() => handleAction('Download')} className="text-gray-400 hover:text-white transition-colors flex items-center space-x-3 text-sm uppercase tracking-widest border border-white/20 px-6 py-3 rounded-full hover:bg-white/10">
                      <Download size={18} /> <span>Download Series</span>
                    </button>
                  </div>
                  
                  <div className="w-full h-2 bg-white/10 rounded-full overflow-hidden cursor-pointer relative group">
                    <div className="w-1/3 h-full bg-white relative">
                      <div className="absolute right-0 top-1/2 -translate-y-1/2 w-4 h-4 bg-white rounded-full shadow-lg opacity-0 group-hover:opacity-100 transition-opacity"></div>
                    </div>
                  </div>
                  <div className="flex justify-between text-sm text-gray-500 mt-4 font-mono">
                    <span>15:04</span>
                    <span>45:20</span>
                  </div>
                </div>
              </div>

              {/* Episode List */}
              <h3 className="text-3xl font-bold mb-8 tracking-tight">Tracklist</h3>
              <div className="space-y-4">
                {episodes.map((ep, i) => (
                  <div 
                    key={i} 
                    className="flex justify-between items-center p-6 border border-white/10 rounded-xl hover:bg-white/5 hover:border-white/30 transition-all duration-300 cursor-pointer group" 
                    onClick={() => handleAction('Play Episode')}
                  >
                    <div className="flex items-center space-x-6">
                      <div className="w-10 h-10 rounded-full border border-white/20 flex items-center justify-center group-hover:bg-white group-hover:text-black transition-colors">
                        <Play size={16} className="ml-1" />
                      </div>
                      <span className="font-medium text-lg group-hover:text-white text-gray-300 transition-colors">{ep.title}</span>
                    </div>
                    <span className="text-gray-500 text-sm font-mono">{ep.time}</span>
                  </div>
                ))}
              </div>
            </div>
          </ScrollReveal>
        </div>
      </div>
    </>
  );
};

export default PodcastDetailPage;