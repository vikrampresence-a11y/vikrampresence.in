
import React from 'react';
import { Helmet } from 'react-helmet';
import { motion } from 'framer-motion';
import { Target, Activity, Shield } from 'lucide-react';

const AboutPage = () => {
  return (
    <>
      <Helmet>
        <title>About Vikram Presence - Premium Digital Products</title>
        <meta name="description" content="Learn about Vikram Presence and how we help people build clarity, discipline, and confidence through ebooks and courses." />
      </Helmet>

      <div className="bg-black min-h-screen text-white pt-32 pb-24 font-sans">
        <div className="container mx-auto px-6 max-w-4xl">
          
          <motion.div 
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8 }}
            className="text-center mb-20"
          >
            <h1 className="text-5xl md:text-7xl font-bold mb-8 tracking-tighter text-white drop-shadow-[0_0_15px_rgba(255,255,255,0.2)]">Who We Are</h1>
            <div className="w-16 h-1 bg-[#FFD700] mx-auto mb-10 shadow-[0_0_10px_rgba(255,215,0,0.5)]"></div>
          </motion.div>

          <motion.div 
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.8, delay: 0.2 }}
            className="prose prose-invert prose-lg max-w-none font-light leading-relaxed text-white mb-24"
          >
            <p className="text-2xl text-white font-medium mb-10 text-center leading-snug">
              "Vikram Presence helps you build clarity, discipline, and confidence. We create practical ebooks and structured courses designed for real life improvement. Everything is honest, grounded, and focused on what actually works."
            </p>
            
            <p className="mb-8">
              The internet is full of noise. Gurus yelling at you to wake up at 4 AM, hustle harder, and manifest your dreams. But when you're genuinely stuck, yelling doesn't help. Hype doesn't build systems.
            </p>
            
            <p className="mb-8">
              We believe in a different approach. A calm, honest, human approach. We act as a mentor, providing you with the exact frameworks needed to untangle your mind and start taking meaningful action. No exaggeration. No fake promises.
            </p>
          </motion.div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-10 mb-24">
            {[
              { icon: Target, title: "Clarity", desc: "Eliminate cognitive friction and understand exactly what you need to do." },
              { icon: Activity, title: "Discipline", desc: "Build systems that work even when your motivation completely disappears." },
              { icon: Shield, title: "Confidence", desc: "Develop genuine self-belief through consistent, undeniable action." }
            ].map((val, i) => (
              <motion.div 
                key={i}
                initial={{ opacity: 0, y: 20 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true }}
                transition={{ delay: i * 0.2 }}
                className="bg-[#0a0a0a] border border-[#FFD700]/20 p-8 rounded-2xl text-center hover:border-[#FFD700] transition-colors shadow-[0_0_15px_rgba(255,215,0,0.05)] hover:shadow-[0_0_30px_rgba(255,215,0,0.2)]"
              >
                <div className="w-14 h-14 rounded-full bg-[#FFD700]/10 flex items-center justify-center mx-auto mb-6">
                  <val.icon className="text-[#FFD700]" size={24} />
                </div>
                <h3 className="text-xl font-bold text-white mb-3">{val.title}</h3>
                <p className="text-sm text-white font-light">{val.desc}</p>
              </motion.div>
            ))}
          </div>

          <motion.div 
            initial={{ opacity: 0 }}
            whileInView={{ opacity: 1 }}
            viewport={{ once: true }}
            className="bg-black border border-[#FFD700]/30 p-10 md:p-16 rounded-3xl text-center shadow-[0_0_40px_rgba(255,215,0,0.15)]"
          >
            <h2 className="text-3xl font-bold text-white mb-6 tracking-tighter">Our Offerings</h2>
            <p className="text-white font-light mb-10 max-w-2xl mx-auto">
              We distill complex psychological concepts into two formats: <strong>Ebooks</strong> for deep, reflective study, and <strong>Courses</strong> for structured, step-by-step implementation.
            </p>
            <a href="/shop" className="inline-block px-8 py-4 bg-[#FFD700] text-black font-bold uppercase tracking-widest text-sm rounded-full hover:bg-yellow-400 transition-colors shadow-[0_0_20px_rgba(255,215,0,0.3)] hover:shadow-[0_0_40px_rgba(255,215,0,0.6)]">
              Explore The Shop
            </a>
          </motion.div>

        </div>
      </div>
    </>
  );
};

export default AboutPage;
