import React from 'react';
import { Link } from 'react-router-dom';
import { Play } from 'lucide-react';

const CourseCard = ({ id, title, description, lessons, difficulty, price }) => {
  return (
    <Link to={`/courses/${id}`} className="block group h-full">
      <div className="bg-black border border-white/10 rounded-xl p-8 h-full flex flex-col hover-lift hover-glow relative overflow-hidden">
        <div className="absolute top-0 right-0 w-32 h-32 bg-white/5 rounded-bl-full -mr-16 -mt-16 transition-transform duration-500 group-hover:scale-150"></div>
        
        <div className="relative z-10 flex flex-col h-full">
          <div className="flex justify-between items-start mb-8">
            <span className="px-3 py-1 bg-white/10 rounded-full text-xs uppercase tracking-widest font-semibold text-white border border-white/10">
              {difficulty}
            </span>
            <span className="text-gray-500 text-xs font-mono uppercase tracking-widest flex items-center">
              <Play size={12} className="mr-1" /> {lessons} Modules
            </span>
          </div>
          
          <h3 className="text-2xl font-bold text-white mb-4 leading-tight tracking-tight">
            {title}
          </h3>
          
          <p className="text-gray-400 text-sm mb-8 font-light leading-relaxed flex-grow">
            {description}
          </p>
          
          <div className="flex items-center justify-between mt-auto pt-6 border-t border-white/10">
            <span className="text-xl font-bold text-white">{price}</span>
            <span className="text-xs text-white uppercase tracking-widest font-bold group-hover:text-gray-300 transition-colors flex items-center">
              Enroll <span className="ml-2 group-hover:translate-x-2 transition-transform duration-300">→</span>
            </span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default CourseCard;