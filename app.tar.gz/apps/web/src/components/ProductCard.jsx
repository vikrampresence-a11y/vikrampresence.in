import React from 'react';
import { useToast } from '@/components/ui/use-toast';

const ProductCard = ({ title, description, price, type }) => {
  const { toast } = useToast();

  const handlePurchase = () => {
    toast({
      title: "🚧 Purchase not implemented yet",
      description: "This feature isn't implemented yet—but don't worry! You can request it in your next prompt! 🚀",
    });
  };

  return (
    <div className="bg-black border border-white/20 p-8 hover-lift hover-glow group">
      <div className="mb-4">
        <span className="text-gray-400 text-xs uppercase tracking-wider">{type}</span>
      </div>
      
      <h3 className="text-2xl font-bold text-white mb-4 text-reveal">{title}</h3>
      
      <p className="text-gray-400 mb-6 leading-relaxed">{description}</p>
      
      <div className="flex items-center justify-between mb-6">
        <span className="text-3xl font-bold text-white">{price}</span>
      </div>
      
      <button
        onClick={handlePurchase}
        className="w-full px-6 py-3 bg-white text-black font-semibold hover:bg-gray-200 transition-all duration-300 uppercase tracking-wider text-sm btn-primary"
      >
        Get Access
      </button>
      
      <div className="mt-4 pt-4 border-t border-white/10">
        <p className="text-gray-500 text-xs">Instant digital delivery</p>
      </div>
    </div>
  );
};

export default ProductCard;