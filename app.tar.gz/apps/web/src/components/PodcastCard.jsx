import React from 'react';
import { Link } from 'react-router-dom';
import { PlayCircle } from 'lucide-react';

const PodcastCard = ({ id, title, description, episodes, price }) => {
  return (
    <Link to={`/podcasts/${id}`} className="block group h-full">
      <div className="bg-black border border-white/10 rounded-xl p-8 h-full flex flex-col hover-lift hover-glow relative overflow-hidden">
        {/* Subtle background gradient on hover */}
        <div className="absolute inset-0 bg-gradient-to-br from-white/5 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500"></div>
        
        <div className="relative z-10 flex flex-col h-full">
          <div className="w-14 h-14 bg-white text-black rounded-full flex items-center justify-center mb-8 group-hover:scale-110 transition-transform duration-500 shadow-lg">
            <PlayCircle size={28} className="ml-1" />
          </div>
          
          <h3 className="text-2xl font-bold text-white mb-4 leading-tight tracking-tight group-hover:text-[#FFD700] transition-colors">
            {title}
          </h3>
          
          <p className="text-gray-400 text-sm mb-8 line-clamp-3 font-light leading-relaxed flex-grow">
            {description}
          </p>
          
          <div className="flex items-center justify-between mt-auto pt-6 border-t border-white/10">
            <div className="flex flex-col">
              <span className="text-xs text-gray-500 uppercase tracking-widest font-semibold mb-1">
                {episodes} Episodes
              </span>
              <span className="text-lg font-bold text-white">{price}</span>
            </div>
            <div className="text-xs text-[#FFD700] uppercase tracking-widest font-bold opacity-0 -translate-x-4 group-hover:opacity-100 group-hover:translate-x-0 transition-all duration-300">
              Listen Now →
            </div>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default PodcastCard;