import React from 'react';
import { Link } from 'react-router-dom';

const EbookCard = ({ id, title, description, price, image }) => {
  return (
    <Link to={`/ebooks/${id}`} className="block group h-full">
      <div className="bg-black border border-white/10 rounded-xl overflow-hidden h-full flex flex-col hover-lift hover-glow">
        <div className="aspect-[3/4] overflow-hidden relative bg-white/5">
          <div className="absolute inset-0 bg-black/40 group-hover:bg-black/10 transition-colors duration-500 z-10"></div>
          <img 
            src={image} 
            alt={title} 
            className="w-full h-full object-cover grayscale group-hover:grayscale-0 group-hover:scale-105 transition-all duration-700" 
          />
          <div className="absolute top-4 right-4 z-20 bg-black/80 backdrop-blur-sm px-3 py-1 rounded-full border border-white/20">
            <span className="text-white text-xs font-bold tracking-wider">{price}</span>
          </div>
        </div>
        
        <div className="p-8 flex flex-col flex-grow relative">
          <h3 className="text-xl font-bold text-white mb-3 leading-tight tracking-tight">
            {title}
          </h3>
          <p className="text-gray-400 text-sm mb-6 line-clamp-2 font-light leading-relaxed flex-grow">
            {description}
          </p>
          <div className="text-xs text-white uppercase tracking-widest font-bold flex items-center">
            Read Preview <span className="ml-2 group-hover:translate-x-2 transition-transform duration-300">→</span>
          </div>
        </div>
      </div>
    </Link>
  );
};

export default EbookCard;