import React from 'react';

const AnimatedLogo = ({ className = '', size = 40 }) => {
  return (
    <div className={`flex items-center justify-center ${className}`}>
      <svg
        width={size}
        height={size}
        viewBox="0 0 100 100"
        fill="none"
        xmlns="http://www.w3.org/2000/svg"
        className="v-glow"
      >
        <path
          d="M20 20 L50 80 L80 20"
          stroke="white"
          strokeWidth="8"
          strokeLinecap="round"
          strokeLinejoin="round"
          className="drop-shadow-lg"
        />
      </svg>
    </div>
  );
};

export default AnimatedLogo;