const ALLOWED_IPS = [
    "86.106.20.28", // L2
    "86.106.20.24", // L3
]

module.exports = {
    ALLOWED_IPS,
}
