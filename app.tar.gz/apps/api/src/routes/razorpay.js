import express from 'express';
import Razorpay from 'razorpay';
import crypto from 'crypto';
import logger from '../utils/logger.js';

const router = express.Router();

// Validate Razorpay API keys at startup
const keyId = process.env.RAZORPAY_KEY_ID;
const keySecret = process.env.RAZORPAY_KEY_SECRET;

logger.info('Razorpay Key ID loaded:', keyId ? 'YES' : 'NO');
logger.info('Razorpay Key Secret loaded:', keySecret ? 'YES' : 'NO');

if (!keyId || !keySecret) {
  throw new Error('Razorpay credentials not configured. Set RAZORPAY_KEY_ID and RAZORPAY_KEY_SECRET in .env');
}

// Initialize Razorpay with environment variables
const razorpay = new Razorpay({
  key_id: keyId,
  key_secret: keySecret,
});

logger.info('Razorpay instance initialized successfully');

// Create order endpoint
router.post('/create-order', async (req, res) => {
  const { amount, currency = 'INR', receipt, description } = req.body;

  if (!amount) {
    return res.status(400).json({ error: 'Amount is required' });
  }

  // Verify credentials are loaded
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
    throw new Error('Razorpay credentials not configured');
  }

  const orderOptions = {
    amount: Math.round(amount * 100), // Convert to paise
    currency,
    receipt: receipt || `receipt_${Date.now()}`,
  };

  if (description) {
    orderOptions.description = description;
  }

  logger.info('Creating Razorpay order with options:', orderOptions);

  const order = await razorpay.orders.create(orderOptions);

  logger.info('Razorpay order created successfully:', order.id);

  res.json({
    orderId: order.id,
    amount: order.amount,
    currency: order.currency,
    status: order.status,
  });
});

// Verify payment endpoint
router.post('/verify-payment', async (req, res) => {
  const { orderId, paymentId, signature } = req.body;

  if (!orderId || !paymentId || !signature) {
    return res.status(400).json({ error: 'Order ID, Payment ID, and Signature are required' });
  }

  // Verify credentials are loaded
  if (!process.env.RAZORPAY_KEY_ID || !process.env.RAZORPAY_KEY_SECRET) {
    throw new Error('Razorpay credentials not configured');
  }

  const hmac = crypto.createHmac('sha256', process.env.RAZORPAY_KEY_SECRET);
  hmac.update(`${orderId}|${paymentId}`);
  const generatedSignature = hmac.digest('hex');

  if (generatedSignature !== signature) {
    throw new Error('Payment verification failed');
  }

  logger.info('Payment verified successfully for order:', orderId);

  res.json({
    success: true,
    message: 'Payment verified successfully',
    orderId,
    paymentId,
  });
});

export default router;