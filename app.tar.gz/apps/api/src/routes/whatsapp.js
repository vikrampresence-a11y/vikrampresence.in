
import express from 'express';

const router = express.Router();

// WhatsApp functionality has been disabled
// Twilio initialization and endpoints removed to prevent startup errors

export default router;
